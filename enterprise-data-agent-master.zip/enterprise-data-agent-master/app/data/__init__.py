"""Database gateway implementations."""
