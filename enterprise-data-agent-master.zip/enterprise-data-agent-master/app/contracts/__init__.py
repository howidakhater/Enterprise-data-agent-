"""Public API contracts."""
