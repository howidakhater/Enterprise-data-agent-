"""LLM gateway implementations."""
